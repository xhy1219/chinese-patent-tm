import re
import os

#build hashmap for ncbi_id to approved gene symbols
d = {}
t=[]
test=[]
with open("./hashmapgene/approved symbol_ncbiid.txt") as f:    
    for line in f:
        listedline = line.strip().split('\t') # split around the '\t' sign
        if len(listedline) == 2: # the'\t'sign in there
           d[listedline[1]] = listedline[0]
           
#read all the english corpus
path = "./englishtxt191" 
files= os.listdir(path)
english_corpus = []
for file in files: 
          f = open(path+"/"+file);
          iter_f = iter(f);
          file=iter_f.read()
          english_corpus.append(file)
          
#find all the potential gene names in the corpus
#note:not sure the re.findall is comleted, will check later
potential_gene_names=[]
for i in english_corpus:
    a=re.findall(r"[a-zA-Z]+\d+|[a-zA-Z]+\d+[a-zA-Z]|[a-zA-Z]+\d+[-]+\d", i, flags=0)
    potential_gene_names.append(a)
#print(b)

#make hashmap for previous symbols to approved symbols only if previous symbols existed
dd={}
with open("./approved_previous.txt") as f:    
    for line in f:
        listedline = line.strip().split('\t') # split around the '\t' sign
        if len(listedline) == 2: # the'\t'sign in there
           dd[listedline[0]] = listedline[1].split(",")

result = []#make approved to multiple previous into aprroved to single previous
for k, v in dd.items():
     result.extend(zip([k,]*len(v), v))

pre2aprroved_genenames = {}
for i in result:
   pre2aprroved_genenames[i[1]] = i[0]  
   
#make a list of previous and approved gene symbols
with open("./approved_previous.txt") as f:
    a=f.readlines()
aa=[]
previous_approved_gene_names=[]
for i in a:
    j=re.sub(u'\t\n|\n',"",i)
    z=re.sub(u',|or',"\t",j)
    x=z.split("\t")
    aa.append(x)    
for i in aa:
    for j in i:
        x = j.strip()
        previous_approved_gene_names.append(x)

approved_names=[]
with open("./approved_symbol.txt") as f:
    a=f.readlines()
for i in a:
    j=re.sub(u'\n',"",i)
    approved_names.append(j)

pre2approved_gene_names=[]
pre2approved_gene_names = [[pre2aprroved_genenames[key] for a in t for key in pre2aprroved_genenames if a==key] for t in potential_gene_names]
#extract (only)approved symbols in potential gene names
approved_genenames=[]
approved_genenames=[[a for a in t for x in approved_names if a ==x] for t in potential_gene_names]

#merge lists
def list_merge(a,b):
    c = []
    for i in range(len(a)):
        c.append(a[i]+b[i])
    return c
all_mined_genesymbols=list_merge(pre2approved_gene_names,approved_genenames)